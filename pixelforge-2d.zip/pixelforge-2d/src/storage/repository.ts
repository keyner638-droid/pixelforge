import { formatIssues, isObj, migrateBundle, validateBundle, fail } from "../model";
import type { ProjectBundle, Result, ValidationIssue } from "../model";
import type { KeyValueStore } from "./kv";

export interface ProjectSummary {
  id: string;
  name: string;
  updatedAt: string;
  sceneCount: number;
  /** El contenido guardado no pasa la validación. No se borra ni se oculta. */
  damaged: boolean;
}

export interface AutosaveEntry {
  bundle: ProjectBundle;
  autosavedAt: string;
}

export interface ProjectRepository {
  list(): Promise<ProjectSummary[]>;
  load(id: string): Promise<Result<ProjectBundle>>;
  /** Valida, conserva la versión anterior como backup y descarta el autosave. */
  save(bundle: ProjectBundle): Promise<void>;
  remove(id: string): Promise<void>;
  saveAutosave(bundle: ProjectBundle): Promise<void>;
  loadAutosave(id: string): Promise<AutosaveEntry | null>;
  clearAutosave(id: string): Promise<void>;
}

export class StorageError extends Error {
  constructor(
    message: string,
    readonly issues: ValidationIssue[] = [],
  ) {
    super(message);
    this.name = "StorageError";
  }
}

function readBundle(raw: unknown): Result<ProjectBundle> {
  const migrated = migrateBundle(raw);
  if (!migrated.ok) return migrated;
  return validateBundle(migrated.value);
}

export function createProjectRepository(kv: KeyValueStore, now: () => string = () => new Date().toISOString()): ProjectRepository {
  return {
    async list() {
      const rows = await kv.entries("projects");
      const out: ProjectSummary[] = rows.map(([key, raw]) => {
        const r = readBundle(raw);
        if (r.ok) {
          const p = r.value.project;
          return { id: p.id, name: p.name, updatedAt: p.updatedAt, sceneCount: r.value.scenes.length, damaged: false };
        }
        const proj = isObj(raw) && isObj(raw.project) ? raw.project : {};
        return {
          id: key,
          name: typeof proj.name === "string" && proj.name ? proj.name : "(proyecto dañado)",
          updatedAt: typeof proj.updatedAt === "string" ? proj.updatedAt : "",
          sceneCount: 0,
          damaged: true,
        };
      });
      return out.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    },

    async load(id) {
      const raw = await kv.get("projects", id);
      if (raw === undefined) return fail("id", "No existe el proyecto solicitado.");
      return readBundle(raw);
    },

    async save(bundle) {
      const v = validateBundle(bundle);
      if (!v.ok) throw new StorageError(`No se guardó: ${formatIssues(v.issues)}`, v.issues);
      const id = bundle.project.id;
      const previous = await kv.get("projects", id);
      if (previous !== undefined) await kv.put("backups", id, previous);
      await kv.put("projects", id, bundle);
      await kv.delete("autosaves", id);
    },

    async remove(id) {
      await kv.delete("projects", id);
      await kv.delete("autosaves", id);
      await kv.delete("backups", id);
    },

    async saveAutosave(bundle) {
      await kv.put("autosaves", bundle.project.id, { bundle, autosavedAt: now() });
    },

    async loadAutosave(id) {
      const raw = await kv.get("autosaves", id);
      if (!isObj(raw)) return null;
      const r = readBundle(raw.bundle);
      if (!r.ok) return null;
      return { bundle: r.value, autosavedAt: typeof raw.autosavedAt === "string" ? raw.autosavedAt : "" };
    },

    async clearAutosave(id) {
      await kv.delete("autosaves", id);
    },
  };
}
