import type { Collection, KeyValueStore } from "./kv";

const DB_NAME = "pixelforge2d";
const DB_VERSION = 1;
const STORES: Collection[] = ["projects", "autosaves", "backups"];

function request<T>(r: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error ?? new Error("Error de IndexedDB."));
  });
}

function done(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("Error de IndexedDB."));
    tx.onabort = () => reject(tx.error ?? new Error("Transacción cancelada."));
  });
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const open = indexedDB.open(DB_NAME, DB_VERSION);
    open.onupgradeneeded = () => {
      const db = open.result;
      for (const name of STORES) {
        if (!db.objectStoreNames.contains(name)) db.createObjectStore(name);
      }
    };
    open.onsuccess = () => resolve(open.result);
    open.onerror = () => reject(open.error ?? new Error("No se pudo abrir el almacenamiento local."));
  });
}

export function createIndexedDbKv(): KeyValueStore {
  let dbPromise: Promise<IDBDatabase> | undefined;
  const db = () => (dbPromise ??= openDb());

  return {
    async get(c, key) {
      const tx = (await db()).transaction(c, "readonly");
      return request(tx.objectStore(c).get(key));
    },
    async put(c, key, value) {
      const tx = (await db()).transaction(c, "readwrite");
      tx.objectStore(c).put(value, key);
      await done(tx);
    },
    async delete(c, key) {
      const tx = (await db()).transaction(c, "readwrite");
      tx.objectStore(c).delete(key);
      await done(tx);
    },
    async entries(c) {
      const tx = (await db()).transaction(c, "readonly");
      const store = tx.objectStore(c);
      const [keys, values] = await Promise.all([request(store.getAllKeys()), request(store.getAll())]);
      return keys.map((k, i) => [String(k), values[i]] as [string, unknown]);
    },
  };
}
