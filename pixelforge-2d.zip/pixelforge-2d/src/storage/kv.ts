export type Collection = "projects" | "autosaves" | "backups";

/** Almacén clave-valor mínimo. Las implementaciones copian los valores (como IndexedDB). */
export interface KeyValueStore {
  get(collection: Collection, key: string): Promise<unknown | undefined>;
  put(collection: Collection, key: string, value: unknown): Promise<void>;
  delete(collection: Collection, key: string): Promise<void>;
  entries(collection: Collection): Promise<Array<[string, unknown]>>;
}

export function createMemoryKv(): KeyValueStore {
  const data: Record<Collection, Map<string, unknown>> = {
    projects: new Map(),
    autosaves: new Map(),
    backups: new Map(),
  };
  return {
    async get(c, key) {
      const v = data[c].get(key);
      return v === undefined ? undefined : structuredClone(v);
    },
    async put(c, key, value) {
      data[c].set(key, structuredClone(value));
    },
    async delete(c, key) {
      data[c].delete(key);
    },
    async entries(c) {
      return [...data[c].entries()].map(([k, v]) => [k, structuredClone(v)] as [string, unknown]);
    },
  };
}
