import type { ProjectBundle } from "./types";

export interface ValidationIssue {
  path: string;
  message: string;
}

export type Result<T> = { ok: true; value: T } | { ok: false; issues: ValidationIssue[] };

type Obj = Record<string, unknown>;

export const isObj = (v: unknown): v is Obj =>
  typeof v === "object" && v !== null && !Array.isArray(v);

export function fail(path: string, message: string): { ok: false; issues: ValidationIssue[] } {
  return { ok: false, issues: [{ path, message }] };
}

export function formatIssues(issues: ValidationIssue[]): string {
  return issues.map((i) => (i.path ? `${i.path}: ${i.message}` : i.message)).join(" · ");
}

function checkString(o: Obj, key: string, path: string, out: ValidationIssue[]): string | undefined {
  const v = o[key];
  if (typeof v !== "string" || v.trim() === "") {
    out.push({ path: `${path}.${key}`, message: "Falta este campo o no es un texto válido." });
    return undefined;
  }
  return v;
}

function checkDate(o: Obj, key: string, path: string, out: ValidationIssue[]): void {
  const v = checkString(o, key, path, out);
  if (v !== undefined && Number.isNaN(Date.parse(v))) {
    out.push({ path: `${path}.${key}`, message: "No es una fecha válida (formato ISO)." });
  }
}

function checkPositiveInt(o: Obj, key: string, path: string, out: ValidationIssue[]): void {
  const v = o[key];
  if (typeof v !== "number" || !Number.isInteger(v) || v <= 0) {
    out.push({ path: `${path}.${key}`, message: "Debe ser un número entero mayor que 0." });
  }
}

function checkStringArray(o: Obj, key: string, path: string, out: ValidationIssue[]): string[] {
  const v = o[key];
  if (!Array.isArray(v) || v.some((x) => typeof x !== "string" || x === "")) {
    out.push({ path: `${path}.${key}`, message: "Debe ser una lista de IDs (textos)." });
    return [];
  }
  return v as string[];
}

function findDuplicates(values: string[]): string[] {
  const seen = new Set<string>();
  const dup = new Set<string>();
  for (const v of values) (seen.has(v) ? dup : seen).add(v);
  return [...dup];
}

function validateSettings(s: unknown, out: ValidationIssue[]): void {
  const p = "project.settings";
  if (!isObj(s)) {
    out.push({ path: p, message: "Faltan los ajustes del proyecto." });
    return;
  }
  for (const k of ["logicalWidth", "logicalHeight", "tileWidth", "tileHeight"]) {
    checkPositiveInt(s, k, p, out);
  }
  if (s.targetFps !== 30 && s.targetFps !== 60) {
    out.push({ path: `${p}.targetFps`, message: "Debe ser 30 o 60." });
  }
  if (typeof s.pixelPerfect !== "boolean") {
    out.push({ path: `${p}.pixelPerfect`, message: "Debe ser verdadero o falso." });
  }
  if (s.locale !== "es") {
    out.push({ path: `${p}.locale`, message: "Por ahora el único idioma admitido es «es»." });
  }
}

function validateScene(s: unknown, index: number, out: ValidationIssue[]): string | undefined {
  const p = `scenes[${index}]`;
  if (!isObj(s)) {
    out.push({ path: p, message: "La escena no es un objeto válido." });
    return undefined;
  }
  const id = checkString(s, "id", p, out);
  checkString(s, "name", p, out);
  checkPositiveInt(s, "width", p, out);
  checkPositiveInt(s, "height", p, out);
  checkStringArray(s, "layerIds", p, out);
  checkStringArray(s, "objectIds", p, out);
  const cam = s.camera;
  if (!isObj(cam) || typeof cam.zoom !== "number" || !(cam.zoom > 0)) {
    out.push({ path: `${p}.camera.zoom`, message: "Debe ser un número mayor que 0." });
  }
  return id;
}

/**
 * Valida un proyecto leído de almacenamiento. No elimina campos
 * desconocidos: devuelve el mismo objeto recibido.
 */
export function validateBundle(input: unknown): Result<ProjectBundle> {
  if (!isObj(input)) return fail("", "El proyecto no tiene un formato válido.");
  const out: ValidationIssue[] = [];
  const project = input.project;
  const scenes = input.scenes;

  let sceneIds: string[] = [];
  let startSceneId: string | undefined;

  if (!isObj(project)) {
    out.push({ path: "project", message: "Falta la sección del proyecto." });
  } else {
    checkString(project, "id", "project", out);
    checkString(project, "name", "project", out);
    checkString(project, "schemaVersion", "project", out);
    checkString(project, "editorVersion", "project", out);
    checkDate(project, "createdAt", "project", out);
    checkDate(project, "updatedAt", "project", out);
    validateSettings(project.settings, out);
    sceneIds = checkStringArray(project, "sceneIds", "project", out);
    startSceneId = checkString(project, "startSceneId", "project", out);
    checkStringArray(project, "assetIds", "project", out);
    checkStringArray(project, "prefabIds", "project", out);
  }

  const realIds: string[] = [];
  if (!Array.isArray(scenes)) {
    out.push({ path: "scenes", message: "Falta la lista de escenas." });
  } else {
    scenes.forEach((s, i) => {
      const id = validateScene(s, i, out);
      if (id !== undefined) realIds.push(id);
    });
  }

  for (const d of findDuplicates(sceneIds)) {
    out.push({ path: "project.sceneIds", message: `El ID de escena «${d}» está repetido.` });
  }
  for (const d of findDuplicates(realIds)) {
    out.push({ path: "scenes", message: `Hay dos escenas con el mismo ID «${d}».` });
  }
  if (Array.isArray(scenes) && isObj(project)) {
    for (const id of sceneIds) {
      if (!realIds.includes(id)) {
        out.push({ path: "project.sceneIds", message: `La escena «${id}» está en la lista pero no existe.` });
      }
    }
    for (const id of realIds) {
      if (!sceneIds.includes(id)) {
        out.push({ path: "scenes", message: `La escena «${id}» existe pero no está en project.sceneIds.` });
      }
    }
    if (startSceneId !== undefined && !sceneIds.includes(startSceneId)) {
      out.push({ path: "project.startSceneId", message: "La escena inicial no existe en el proyecto." });
    }
  }

  return out.length > 0 ? { ok: false, issues: out } : { ok: true, value: input as unknown as ProjectBundle };
}
