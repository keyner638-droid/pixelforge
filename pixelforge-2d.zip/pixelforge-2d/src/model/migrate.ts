import { SCHEMA_VERSION } from "./types";
import { fail, isObj, type Result } from "./validate";

export interface Migration {
  from: string;
  to: string;
  run(raw: Record<string, unknown>): Record<string, unknown>;
}

/** Migraciones registradas. Vacía mientras exista una sola versión de esquema. */
export const MIGRATIONS: Migration[] = [];

const major = (v: string): number => Number.parseInt(v.split(".")[0] ?? "", 10);

/**
 * Lleva un proyecto leído al esquema actual sin modificar el original (trabaja sobre una copia).
 * - Misma versión mayor sin migración registrada: se acepta tal cual (campos desconocidos se conservan).
 * - Versión mayor más nueva: se rechaza sin tocar los datos.
 */
export function migrateBundle(
  raw: unknown,
  migrations: Migration[] = MIGRATIONS,
  target: string = SCHEMA_VERSION,
): Result<unknown> {
  if (!isObj(raw) || !isObj(raw.project) || typeof raw.project.schemaVersion !== "string") {
    return fail("project.schemaVersion", "No se pudo leer la versión del proyecto.");
  }
  let current: Record<string, unknown> = structuredClone(raw);
  let version = (current.project as Record<string, unknown>).schemaVersion as string;
  const visited = new Set<string>();

  while (version !== target) {
    if (visited.has(version)) return fail("project.schemaVersion", "Las migraciones forman un ciclo.");
    visited.add(version);
    const step = migrations.find((m) => m.from === version);
    if (!step) {
      const vMajor = major(version);
      const tMajor = major(target);
      if (Number.isNaN(vMajor)) return fail("project.schemaVersion", `La versión «${version}» no es válida.`);
      if (vMajor > tMajor) {
        return fail(
          "project.schemaVersion",
          `El proyecto fue creado con una versión más nueva del editor (esquema ${version}). Actualiza PixelForge 2D para abrirlo.`,
        );
      }
      if (vMajor === tMajor) return { ok: true, value: current };
      return fail("project.schemaVersion", `No existe una migración desde la versión ${version}.`);
    }
    current = step.run(current);
    version = step.to;
    (current.project as Record<string, unknown>).schemaVersion = version;
  }
  return { ok: true, value: current };
}
