import { createId } from "./ids";
import {
  EDITOR_VERSION,
  SCHEMA_VERSION,
  type ProjectBundle,
  type ProjectSettings,
  type Scene,
} from "./types";

export const DEFAULT_PROJECT_NAME = "Proyecto sin nombre";
export const DEFAULT_SCENE_NAME = "Escena";

export const DEFAULT_SETTINGS: ProjectSettings = {
  logicalWidth: 320,
  logicalHeight: 180,
  tileWidth: 16,
  tileHeight: 16,
  targetFps: 60,
  pixelPerfect: true,
  locale: "es",
};

export const nowIso = (): string => new Date().toISOString();

export function createScene(name: string): Scene {
  return {
    id: createId(),
    name: name.trim() || DEFAULT_SCENE_NAME,
    width: 40,
    height: 30,
    layerIds: [],
    objectIds: [],
    camera: { zoom: 1 },
  };
}

export function createEmptyBundle(name: string, now: () => string = nowIso): ProjectBundle {
  const scene = createScene("Escena 1");
  const t = now();
  return {
    project: {
      id: createId(),
      name: name.trim() || DEFAULT_PROJECT_NAME,
      schemaVersion: SCHEMA_VERSION,
      editorVersion: EDITOR_VERSION,
      createdAt: t,
      updatedAt: t,
      settings: { ...DEFAULT_SETTINGS },
      sceneIds: [scene.id],
      startSceneId: scene.id,
      assetIds: [],
      prefabIds: [],
    },
    scenes: [scene],
  };
}

/** Copia independiente: todos los IDs nuevos. */
export function duplicateBundle(src: ProjectBundle, newName: string, now: () => string = nowIso): ProjectBundle {
  const idMap = new Map<string, string>();
  const scenes = src.scenes.map((s) => {
    const id = createId();
    idMap.set(s.id, id);
    return { ...structuredClone(s), id };
  });
  const t = now();
  return {
    project: {
      ...structuredClone(src.project),
      id: createId(),
      name: newName.trim() || DEFAULT_PROJECT_NAME,
      createdAt: t,
      updatedAt: t,
      sceneIds: src.project.sceneIds.map((id) => idMap.get(id) ?? id),
      startSceneId: idMap.get(src.project.startSceneId) ?? src.project.startSceneId,
    },
    scenes,
  };
}
