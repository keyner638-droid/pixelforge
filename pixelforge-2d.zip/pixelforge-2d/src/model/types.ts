export type Id = string;

export const SCHEMA_VERSION = "1.0.0";
export const EDITOR_VERSION = "0.1.0";

export interface ProjectSettings {
  logicalWidth: number;
  logicalHeight: number;
  tileWidth: number;
  tileHeight: number;
  targetFps: 30 | 60;
  pixelPerfect: boolean;
  locale: "es";
}

export interface CameraConfig {
  zoom: number;
}

export interface Scene {
  id: Id;
  name: string;
  /** Tamaño del mapa en celdas (tiles). */
  width: number;
  height: number;
  layerIds: Id[];
  objectIds: Id[];
  camera: CameraConfig;
}

export interface Project {
  id: Id;
  name: string;
  schemaVersion: string;
  editorVersion: string;
  createdAt: string;
  updatedAt: string;
  settings: ProjectSettings;
  sceneIds: Id[];
  startSceneId: Id;
  assetIds: Id[];
  prefabIds: Id[];
}

/** Unidad que se guarda y se abre: el proyecto y sus escenas. */
export interface ProjectBundle {
  project: Project;
  scenes: Scene[];
}
