import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./editor/App";
import { createEditorStore } from "./editor";
import { createIndexedDbKv, createProjectRepository } from "./storage";
import "./ui/estilos.css";

const store = createEditorStore({ repo: createProjectRepository(createIndexedDbKv()) });

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App store={store} />
  </StrictMode>,
);
