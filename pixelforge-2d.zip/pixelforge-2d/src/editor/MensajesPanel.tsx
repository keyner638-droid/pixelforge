import type { EditorStore, UiMessage } from "./store";
import { t } from "../ui/textos";

export function MensajesPanel({ store, mensajes }: { store: EditorStore; mensajes: UiMessage[] }) {
  if (mensajes.length === 0) return <p>{t.editor.consolaVacia}</p>;
  return (
    <ul className="mensajes" role="log" aria-live="polite">
      {mensajes.map((m) => (
        <li key={m.id} className={`mensaje ${m.level}`}>
          <span>{m.text}</span>
          <button type="button" aria-label={t.editor.cerrarMensaje} onClick={() => store.dismissMessage(m.id)}>
            ✕
          </button>
        </li>
      ))}
    </ul>
  );
}
