import { useEffect } from "react";
import type { EditorStore } from "./store";
import { useEditorState } from "./useEditor";
import { HomeScreen } from "./HomeScreen";
import { EditorShell } from "./EditorShell";

export function App({ store }: { store: EditorStore }) {
  const state = useEditorState(store);

  useEffect(() => {
    void store.refreshList();
  }, [store]);

  return state.screen === "editor" ? (
    <EditorShell store={store} state={state} />
  ) : (
    <HomeScreen store={store} state={state} />
  );
}
