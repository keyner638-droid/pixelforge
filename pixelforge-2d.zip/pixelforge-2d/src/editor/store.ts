import { createEmptyBundle, createScene, duplicateBundle, nowIso } from "../model";
import type { ProjectBundle } from "../model";
import type { AutosaveEntry, ProjectRepository, ProjectSummary } from "../storage";

export type SaveStatus = "guardado" | "sin-guardar" | "guardando" | "error";
export type MessageLevel = "error" | "warning" | "info";

export interface UiMessage {
  id: number;
  level: MessageLevel;
  text: string;
}

export interface EditorState {
  screen: "inicio" | "editor";
  projects: ProjectSummary[];
  bundle: ProjectBundle | null;
  dirty: boolean;
  saveStatus: SaveStatus;
  past: ProjectBundle[];
  future: ProjectBundle[];
  recovery: AutosaveEntry | null;
  messages: UiMessage[];
}

export interface StoreOptions {
  repo: ProjectRepository;
  now?: () => string;
  autosaveDelayMs?: number;
  maxHistory?: number;
}

export interface EditorStore {
  getState(): EditorState;
  subscribe(listener: () => void): () => void;
  refreshList(): Promise<void>;
  createProject(name: string): Promise<void>;
  openProject(id: string): Promise<void>;
  duplicateProject(id: string): Promise<void>;
  deleteProject(id: string): Promise<void>;
  closeProject(): Promise<void>;
  renameProject(name: string): void;
  addScene(): void;
  renameScene(sceneId: string, name: string): void;
  undo(): void;
  redo(): void;
  save(): Promise<void>;
  flushAutosave(): Promise<void>;
  acceptRecovery(): void;
  discardRecovery(): Promise<void>;
  dismissMessage(id: number): void;
}

const errText = (e: unknown): string => (e instanceof Error ? e.message : String(e));

export function createEditorStore(opts: StoreOptions): EditorStore {
  const { repo } = opts;
  const now = opts.now ?? nowIso;
  const delay = opts.autosaveDelayMs ?? 1500;
  const maxHistory = opts.maxHistory ?? 100;

  let state: EditorState = {
    screen: "inicio",
    projects: [],
    bundle: null,
    dirty: false,
    saveStatus: "guardado",
    past: [],
    future: [],
    recovery: null,
    messages: [],
  };
  const listeners = new Set<() => void>();
  let timer: ReturnType<typeof setTimeout> | undefined;
  let nextMessageId = 1;

  function set(patch: Partial<EditorState>): void {
    state = { ...state, ...patch };
    listeners.forEach((l) => l());
  }

  function push(level: MessageLevel, text: string): void {
    set({ messages: [...state.messages, { id: nextMessageId++, level, text }].slice(-50) });
  }

  function clearTimer(): void {
    if (timer !== undefined) clearTimeout(timer);
    timer = undefined;
  }

  function scheduleAutosave(): void {
    clearTimer();
    timer = setTimeout(() => void store.flushAutosave(), delay);
  }

  /** Aplica un cambio al proyecto abierto como una transacción deshacible. */
  function commit(update: (b: ProjectBundle) => ProjectBundle): void {
    const current = state.bundle;
    if (!current) return;
    const changed = update(current);
    if (changed === current) return;
    const next: ProjectBundle = { ...changed, project: { ...changed.project, updatedAt: now() } };
    set({
      bundle: next,
      past: [...state.past, current].slice(-maxHistory),
      future: [],
      dirty: true,
      saveStatus: "sin-guardar",
    });
    scheduleAutosave();
  }

  function enter(bundle: ProjectBundle, recovery: AutosaveEntry | null): void {
    clearTimer();
    set({ screen: "editor", bundle, dirty: false, saveStatus: "guardado", past: [], future: [], recovery });
  }

  const store: EditorStore = {
    getState: () => state,
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },

    async refreshList() {
      try {
        set({ projects: await repo.list() });
      } catch (e) {
        push("error", `No se pudo leer la lista de proyectos: ${errText(e)}`);
      }
    },

    async createProject(name) {
      const bundle = createEmptyBundle(name, now);
      try {
        await repo.save(bundle);
      } catch (e) {
        push("error", errText(e));
        return;
      }
      await store.refreshList();
      enter(bundle, null);
    },

    async openProject(id) {
      try {
        const r = await repo.load(id);
        if (!r.ok) {
          for (const i of r.issues) push("error", `No se pudo abrir el proyecto — ${i.path ? i.path + ": " : ""}${i.message}`);
          return;
        }
        enter(r.value, await repo.loadAutosave(id));
      } catch (e) {
        push("error", `No se pudo abrir el proyecto: ${errText(e)}`);
      }
    },

    async duplicateProject(id) {
      try {
        const r = await repo.load(id);
        if (!r.ok) {
          push("error", `No se puede duplicar: ${r.issues.map((i) => i.message).join(" ")}`);
          return;
        }
        await repo.save(duplicateBundle(r.value, `${r.value.project.name} (copia)`, now));
        await store.refreshList();
      } catch (e) {
        push("error", `No se pudo duplicar el proyecto: ${errText(e)}`);
      }
    },

    async deleteProject(id) {
      try {
        await repo.remove(id);
        await store.refreshList();
      } catch (e) {
        push("error", `No se pudo eliminar el proyecto: ${errText(e)}`);
      }
    },

    async closeProject() {
      if (state.dirty) await store.flushAutosave();
      clearTimer();
      set({ screen: "inicio", bundle: null, dirty: false, saveStatus: "guardado", past: [], future: [], recovery: null });
      await store.refreshList();
    },

    renameProject(name) {
      const clean = name.trim();
      if (!clean) return;
      commit((b) => (b.project.name === clean ? b : { ...b, project: { ...b.project, name: clean } }));
    },

    addScene() {
      commit((b) => {
        const scene = createScene(`Escena ${b.scenes.length + 1}`);
        return {
          project: { ...b.project, sceneIds: [...b.project.sceneIds, scene.id] },
          scenes: [...b.scenes, scene],
        };
      });
    },

    renameScene(sceneId, name) {
      const clean = name.trim();
      if (!clean) return;
      commit((b) => {
        const target = b.scenes.find((s) => s.id === sceneId);
        if (!target || target.name === clean) return b;
        return { ...b, scenes: b.scenes.map((s) => (s.id === sceneId ? { ...s, name: clean } : s)) };
      });
    },

    undo() {
      const prev = state.past[state.past.length - 1];
      if (!prev || !state.bundle) return;
      set({
        bundle: prev,
        past: state.past.slice(0, -1),
        future: [state.bundle, ...state.future],
        dirty: true,
        saveStatus: "sin-guardar",
      });
      scheduleAutosave();
    },

    redo() {
      const next = state.future[0];
      if (!next || !state.bundle) return;
      set({
        bundle: next,
        past: [...state.past, state.bundle],
        future: state.future.slice(1),
        dirty: true,
        saveStatus: "sin-guardar",
      });
      scheduleAutosave();
    },

    async save() {
      const saving = state.bundle;
      if (!saving) return;
      set({ saveStatus: "guardando" });
      try {
        await repo.save(saving);
        if (state.bundle === saving) {
          clearTimer();
          set({ dirty: false, saveStatus: "guardado", recovery: null });
        } else {
          set({ saveStatus: "sin-guardar" });
        }
      } catch (e) {
        set({ saveStatus: "error" });
        push("error", errText(e));
      }
    },

    async flushAutosave() {
      clearTimer();
      const b = state.bundle;
      if (!b || !state.dirty) return;
      try {
        await repo.saveAutosave(b);
      } catch (e) {
        push("warning", `No se pudo guardar la copia automática: ${errText(e)}`);
      }
    },

    acceptRecovery() {
      const rec = state.recovery;
      const current = state.bundle;
      if (!rec || !current) return;
      set({
        bundle: rec.bundle,
        past: [...state.past, current].slice(-maxHistory),
        future: [],
        dirty: true,
        saveStatus: "sin-guardar",
        recovery: null,
      });
      push("info", "Se recuperaron los cambios no guardados. Pulsa Guardar para conservarlos.");
    },

    async discardRecovery() {
      const b = state.bundle;
      set({ recovery: null });
      if (b) {
        try {
          await repo.clearAutosave(b.project.id);
        } catch (e) {
          push("warning", `No se pudo descartar la copia automática: ${errText(e)}`);
        }
      }
    },

    dismissMessage(id) {
      set({ messages: state.messages.filter((m) => m.id !== id) });
    },
  };

  return store;
}
