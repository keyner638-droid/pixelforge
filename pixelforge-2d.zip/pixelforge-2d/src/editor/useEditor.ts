import { useSyncExternalStore } from "react";
import type { EditorState, EditorStore } from "./store";

export function useEditorState(store: EditorStore): EditorState {
  return useSyncExternalStore(store.subscribe, store.getState, store.getState);
}
