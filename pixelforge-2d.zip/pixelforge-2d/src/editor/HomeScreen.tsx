import { useState } from "react";
import type { EditorState, EditorStore } from "./store";
import { MensajesPanel } from "./MensajesPanel";
import { t } from "../ui/textos";

export function HomeScreen({ store, state }: { store: EditorStore; state: EditorState }) {
  const [nombre, setNombre] = useState("");

  function crear(e: React.FormEvent) {
    e.preventDefault();
    void store.createProject(nombre);
    setNombre("");
  }

  return (
    <main className="inicio">
      <header>
        <h1>{t.app}</h1>
        <p>{t.inicio.subtitulo}</p>
      </header>

      <section className="tarjeta" aria-labelledby="nuevo">
        <h2 id="nuevo">{t.inicio.nuevo}</h2>
        <form className="form-fila" onSubmit={crear}>
          <div>
            <label htmlFor="nombre-nuevo">{t.inicio.nombre}</label>
            <input
              id="nombre-nuevo"
              value={nombre}
              placeholder={t.inicio.placeholderNombre}
              onChange={(e) => setNombre(e.target.value)}
            />
          </div>
          <button type="submit" className="primario">
            {t.inicio.crear}
          </button>
        </form>
      </section>

      <section className="tarjeta" aria-labelledby="lista">
        <h2 id="lista">{t.inicio.titulo}</h2>
        {state.projects.length === 0 ? (
          <p>{t.inicio.vacio}</p>
        ) : (
          <ul className="lista">
            {state.projects.map((p) => (
              <li key={p.id} className="proyecto">
                <div className="info">
                  <strong>{p.name}</strong>
                  {p.damaged && <span className="etiqueta-danada">{t.inicio.danado}</span>}
                  <div className="meta">
                    {t.inicio.escenas(p.sceneCount)}
                    {p.updatedAt && ` · ${new Date(p.updatedAt).toLocaleString("es")}`}
                  </div>
                </div>
                <button type="button" onClick={() => void store.openProject(p.id)}>
                  {t.inicio.abrir}
                </button>
                <button type="button" disabled={p.damaged} onClick={() => void store.duplicateProject(p.id)}>
                  {t.inicio.duplicar}
                </button>
                <button
                  type="button"
                  className="peligro"
                  onClick={() => {
                    if (window.confirm(t.inicio.confirmarEliminar(p.name))) void store.deleteProject(p.id);
                  }}
                >
                  {t.inicio.eliminar}
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      {state.messages.length > 0 && (
        <section className="tarjeta" aria-label={t.editor.consola}>
          <MensajesPanel store={store} mensajes={state.messages} />
        </section>
      )}
    </main>
  );
}
