import { useEffect, useState } from "react";
import type { EditorState, EditorStore } from "./store";
import { MensajesPanel } from "./MensajesPanel";
import { t } from "../ui/textos";

function NombreEditable({
  etiqueta,
  valor,
  onCommit,
  className,
}: {
  etiqueta: string;
  valor: string;
  onCommit: (v: string) => void;
  className?: string;
}) {
  const [texto, setTexto] = useState(valor);
  useEffect(() => setTexto(valor), [valor]);
  const confirmar = () => {
    if (texto.trim() === "") setTexto(valor);
    else onCommit(texto);
  };
  return (
    <input
      className={className}
      aria-label={etiqueta}
      value={texto}
      onChange={(e) => setTexto(e.target.value)}
      onBlur={confirmar}
      onKeyDown={(e) => {
        if (e.key === "Enter") e.currentTarget.blur();
        if (e.key === "Escape") setTexto(valor);
      }}
    />
  );
}

export function EditorShell({ store, state }: { store: EditorStore; state: EditorState }) {
  const bundle = state.bundle;

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!(e.ctrlKey || e.metaKey)) return;
      const k = e.key.toLowerCase();
      if (k === "s") {
        e.preventDefault();
        void store.save();
      } else if (k === "z" && !e.shiftKey) {
        if (e.target instanceof HTMLInputElement) return;
        e.preventDefault();
        store.undo();
      } else if (k === "y" || (k === "z" && e.shiftKey)) {
        if (e.target instanceof HTMLInputElement) return;
        e.preventDefault();
        store.redo();
      }
    }
    function onBeforeUnload(e: BeforeUnloadEvent) {
      if (store.getState().dirty) {
        void store.flushAutosave();
        e.preventDefault();
      }
    }
    window.addEventListener("keydown", onKey);
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("beforeunload", onBeforeUnload);
    };
  }, [store]);

  if (!bundle) return null;
  const { project, scenes } = bundle;
  const s = project.settings;

  return (
    <div className="shell">
      <header className="barra">
        <button type="button" onClick={() => void store.closeProject()}>
          ← {t.editor.inicio}
        </button>
        <NombreEditable
          className="nombre"
          etiqueta={t.editor.nombreProyecto}
          valor={project.name}
          onCommit={(v) => store.renameProject(v)}
        />
        <button type="button" onClick={() => store.undo()} disabled={state.past.length === 0}>
          {t.editor.deshacer}
        </button>
        <button type="button" onClick={() => store.redo()} disabled={state.future.length === 0}>
          {t.editor.rehacer}
        </button>
        <button
          type="button"
          className="primario"
          onClick={() => void store.save()}
          disabled={!state.dirty || state.saveStatus === "guardando"}
        >
          {t.editor.guardar}
        </button>
        <button type="button" disabled title={t.editor.jugarMotivo} aria-label={`${t.editor.jugar}. ${t.editor.jugarMotivo}`}>
          {t.editor.jugar}
        </button>
        <button type="button" disabled title={t.editor.exportarMotivo} aria-label={`${t.editor.exportar}. ${t.editor.exportarMotivo}`}>
          {t.editor.exportar}
        </button>
      </header>

      {state.recovery && (
        <div className="aviso" role="alert">
          <p>
            <strong>{t.editor.recuperacionTitulo}</strong> {t.editor.recuperacionTexto}
          </p>
          <button type="button" className="primario" onClick={() => store.acceptRecovery()}>
            {t.editor.recuperar}
          </button>
          <button type="button" onClick={() => void store.discardRecovery()}>
            {t.editor.descartar}
          </button>
        </div>
      )}

      <aside className="panel izq" aria-label={t.editor.escenas}>
        <h3>{t.editor.escenas}</h3>
        {scenes.map((sc) => (
          <div key={sc.id} className="escena">
            <NombreEditable
              etiqueta={t.editor.nombreEscena}
              valor={sc.name}
              onCommit={(v) => store.renameScene(sc.id, v)}
            />
            {sc.id === project.startSceneId && <span className="inicial">{t.editor.escenaInicial}</span>}
          </div>
        ))}
        <button type="button" onClick={() => store.addScene()}>
          + {t.editor.nuevaEscena}
        </button>
      </aside>

      <main className="centro" aria-label={t.editor.viewportTitulo}>
        <div>
          <h2>{t.editor.viewportTitulo}</h2>
          <p>{t.editor.viewportTexto}</p>
        </div>
      </main>

      <aside className="panel der" aria-label={t.editor.inspector}>
        <h3>{t.editor.inspector}</h3>
        <h2>{t.editor.ajustes}</h2>
        <dl>
          <dt>{t.editor.resolucion}</dt>
          <dd>
            {s.logicalWidth}×{s.logicalHeight}
          </dd>
          <dt>{t.editor.tile}</dt>
          <dd>
            {s.tileWidth}×{s.tileHeight}
          </dd>
          <dt>{t.editor.fps}</dt>
          <dd>{s.targetFps}</dd>
          <dt>{t.editor.pixelPerfect}</dt>
          <dd>{s.pixelPerfect ? t.editor.si : t.editor.no}</dd>
        </dl>
      </aside>

      <section className="panel consola" aria-label={t.editor.consola}>
        <h3>{t.editor.consola}</h3>
        <MensajesPanel store={store} mensajes={state.messages} />
      </section>

      <footer className="estado">
        <span role="status" className={state.saveStatus}>
          {t.editor.estado[state.saveStatus]}
        </span>
      </footer>
    </div>
  );
}
