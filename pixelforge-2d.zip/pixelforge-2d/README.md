# PixelForge 2D

Editor visual para crear videojuegos 2D sin escribir código. Especificación completa: `PixelForge2D_Master_Spec.md`.

**Estado:** Fase 0 (fundamentos) implementada; pendiente de verificar con la cadena de herramientas real (ver `docs/TESTING.md`).

## Primera vez (una sola vez)

1. Instala Node.js (versión LTS) desde https://nodejs.org
2. Abre una terminal dentro de esta carpeta y ejecuta:

```bash
npm install react react-dom
npm install -D vite @vitejs/plugin-react typescript vitest @types/react @types/react-dom
```

Esto descarga las dependencias y las registra en `package.json` con sus versiones reales.

## Uso diario

| Comando | Qué hace |
|---|---|
| `npm run dev` | Abre el editor en el navegador (la terminal muestra la dirección, normalmente http://localhost:5173) |
| `npm test` | Ejecuta las pruebas automáticas |
| `npm run typecheck` | Revisa los tipos de TypeScript |
| `npm run build` | Revisa tipos y genera la versión de producción en `dist/` |

## Qué puedes hacer hoy

- Crear, abrir, duplicar y eliminar proyectos (se guardan en el navegador, sin conexión).
- Renombrar el proyecto y sus escenas, añadir escenas, deshacer/rehacer (Ctrl+Z / Ctrl+Y), guardar (Ctrl+S).
- Si el editor se cierra sin guardar, al reabrir el proyecto se ofrece recuperar los cambios.

Jugar, exportar, mapas y objetos llegan en fases posteriores; esos botones están deshabilitados y explican por qué.
