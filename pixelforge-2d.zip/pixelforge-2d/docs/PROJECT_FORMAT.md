# Formato del proyecto (esquema 1.0.0)

Unidad guardada (`ProjectBundle`): `{ project, scenes[] }`. Todo es JSON serializable.

- `project`: `id`, `name`, `schemaVersion`, `editorVersion`, `createdAt`, `updatedAt`, `settings`, `sceneIds`, `startSceneId`, `assetIds`, `prefabIds`.
- `settings`: `logicalWidth`, `logicalHeight`, `tileWidth`, `tileHeight`, `targetFps` (30|60), `pixelPerfect`, `locale` ("es").
- `scene`: `id`, `name`, `width`/`height` (en celdas), `layerIds`, `objectIds`, `camera.zoom`.

Reglas validadas: IDs no vacíos y únicos; `sceneIds` coincide exactamente con los IDs de `scenes`; `startSceneId` existe; fechas ISO.

Versionado: misma versión mayor sin migración → se acepta (campos desconocidos se conservan); mayor más nueva → se rechaza sin tocar datos; anterior → requiere migración registrada en `src/model/migrate.ts` (hoy no hay ninguna).

Almacenamiento local (IndexedDB `pixelforge2d`): colecciones `projects`, `autosaves` (se borra al guardar) y `backups` (versión anterior al sobrescribir).

Decisión pendiente: el spec §7.3 describe una carpeta/ZIP con varios archivos; la exportación a ZIP llega en fases posteriores.
