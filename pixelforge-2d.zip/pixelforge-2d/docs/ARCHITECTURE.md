# Arquitectura (Fase 0)

Monolito modular: un solo `package.json`, módulos como carpetas de `src/`.

| Carpeta | Responsabilidad | Importa de |
|---|---|---|
| `model/` | Tipos, IDs, fábricas, validación y migraciones. Sin dependencias. | — |
| `storage/` | `KeyValueStore` (memoria / IndexedDB) y `ProjectRepository` (guardar, autosave, backup). | `model` |
| `editor/store.ts` | Estado del editor sin React: proyecto abierto, undo/redo, autosave, recuperación, mensajes. | `model`, `storage` |
| `editor/*.tsx` | Interfaz React; solo lee el store y llama sus acciones. | `editor/store`, `ui` |
| `ui/` | Textos centralizados (`textos.ts`) y estilos (tema oscuro). | — |

Reglas: la lógica no vive en componentes React; el estado tiene una sola fuente de verdad (`EditorState`); los cambios del proyecto pasan por `commit()`, que registra el estado anterior para deshacer.

Carpetas del spec que aún no existen (`runtime/`, `logic/`, `systems/`, `assets/`, `exporters/`, `platform/`) se crean cuando tengan una responsabilidad real.

## ADR

- `ADR/0001-validacion-propia.md`
