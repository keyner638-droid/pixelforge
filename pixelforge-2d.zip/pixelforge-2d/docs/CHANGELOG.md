# Registro de cambios

## 0.1.0 — Fase 0 (fundamentos)
- Modelo de proyecto versionado con validación, migraciones y duplicado.
- Almacenamiento local (IndexedDB) con autosave, backup y recuperación.
- Editor base en español, tema oscuro: inicio de proyectos y estructura de paneles.
- Deshacer/rehacer, guardar (Ctrl+S) y recuperación de cambios no guardados.
