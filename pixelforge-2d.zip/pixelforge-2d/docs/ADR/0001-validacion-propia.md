# ADR 0001 — Validación del modelo sin librería externa (por ahora)

- **Contexto:** el spec (§6.1) sugiere Zod o Valibot. En la Fase 0 el modelo es pequeño y se quiso evitar dependencias innecesarias.
- **Decisión:** validadores propios en `src/model/validate.ts`, con rutas de campo y mensajes en español.
- **Consecuencias:** cero dependencias en `model/`; los campos desconocidos se conservan. Si el modelo crece (componentes con esquemas por tipo), reevaluar Zod/Valibot.
- **Revisión:** al empezar la Fase 2 (objetos y prefabs).
