# Pruebas

`npm test` (Vitest, entorno Node). Archivos en `tests/`:

- `model.test.ts`: proyecto vacío, validación con rutas, duplicado, migraciones.
- `storage.test.ts`: guardar/abrir, backup, proyecto dañado sin borrarse, autosave.
- `store.test.ts`: crear/abrir, undo/redo, guardado, recuperación tras cierre simulado, duplicar/eliminar.

## Verificación realizada al crear la Fase 0

En un entorno sin acceso a npm se ejecutaron: las 32 pruebas con un sustituto mínimo de Vitest sobre `node:test`, el chequeo de tipos (`tsc --strict`) de `model`, `storage`, `editor/store.ts` y `tests`, y un recorrido de interfaz en Chromium (crear, editar, deshacer, autosave, recarga, recuperar, guardar, reabrir, duplicar, eliminar; sin errores de consola).

## No verificado todavía

`npm install`, `npm test` con Vitest real, `npm run typecheck` de los `.tsx` (faltaban `@types/react`) y `npm run build` con Vite. Ejecútalos y anota el resultado en el registro de cambios del spec.

Fixtures del spec §24.2 aún pendientes: se añaden con cada fase (proyecto MVP, tileset, diálogo, ZIP malformado…).
