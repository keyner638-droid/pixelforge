import { describe, expect, it } from "vitest";
import { createEditorStore } from "../src/editor";
import { createMemoryKv, createProjectRepository } from "../src/storage";

function setup() {
  const kv = createMemoryKv();
  const repo = createProjectRepository(kv);
  let tick = 0;
  const now = () => new Date(Date.UTC(2026, 10, 1, 0, 0, tick++)).toISOString();
  const make = () => createEditorStore({ repo, now, autosaveDelayMs: 60_000 });
  return { kv, repo, make };
}

describe("editor store", () => {
  it("crea un proyecto vacío que persiste y reabre", async () => {
    const { make } = setup();
    const a = make();
    await a.createProject("Mi juego");
    const id = a.getState().bundle!.project.id;
    expect(a.getState().screen).toBe("editor");

    const b = make();
    await b.refreshList();
    expect(b.getState().projects.map((p) => p.name)).toEqual(["Mi juego"]);
    await b.openProject(id);
    expect(b.getState().bundle!.project.name).toBe("Mi juego");
    expect(b.getState().bundle!.project.id).toBe(id);
  });

  it("edita, deshace y rehace", async () => {
    const { make } = setup();
    const s = make();
    await s.createProject("Original");
    s.renameProject("Nuevo nombre");
    s.addScene();
    expect(s.getState().bundle!.scenes).toHaveLength(2);
    expect(s.getState().dirty).toBe(true);
    s.undo();
    expect(s.getState().bundle!.scenes).toHaveLength(1);
    expect(s.getState().bundle!.project.name).toBe("Nuevo nombre");
    s.undo();
    expect(s.getState().bundle!.project.name).toBe("Original");
    s.redo();
    expect(s.getState().bundle!.project.name).toBe("Nuevo nombre");
    s.renameScene(s.getState().bundle!.scenes[0]!.id, "Aldea");
    expect(s.getState().future).toHaveLength(0);
    expect(s.getState().bundle!.scenes[0]!.name).toBe("Aldea");
  });

  it("ignora renombres vacíos o sin cambios", async () => {
    const { make } = setup();
    const s = make();
    await s.createProject("Igual");
    s.renameProject("   ");
    s.renameProject("Igual");
    expect(s.getState().dirty).toBe(false);
    expect(s.getState().past).toHaveLength(0);
  });

  it("guarda y los cambios sobreviven al reabrir", async () => {
    const { make } = setup();
    const a = make();
    await a.createProject("P");
    a.addScene();
    await a.save();
    expect(a.getState().dirty).toBe(false);
    expect(a.getState().saveStatus).toBe("guardado");
    const id = a.getState().bundle!.project.id;

    const b = make();
    await b.openProject(id);
    expect(b.getState().bundle!.scenes).toHaveLength(2);
    expect(b.getState().recovery).toBeNull();
  });

  it("recupera cambios tras un cierre inesperado simulado", async () => {
    const { make } = setup();
    const a = make();
    await a.createProject("P");
    const id = a.getState().bundle!.project.id;
    a.renameProject("Sin guardar");
    await a.flushAutosave();
    // "cierre inesperado": se abandona la instancia sin guardar y se abre otra

    const b = make();
    await b.openProject(id);
    expect(b.getState().bundle!.project.name).toBe("P");
    expect(b.getState().recovery?.bundle.project.name).toBe("Sin guardar");
    b.acceptRecovery();
    expect(b.getState().bundle!.project.name).toBe("Sin guardar");
    expect(b.getState().dirty).toBe(true);
    await b.save();

    const c = make();
    await c.openProject(id);
    expect(c.getState().bundle!.project.name).toBe("Sin guardar");
    expect(c.getState().recovery).toBeNull();
  });

  it("descarta la recuperación y borra el autosave", async () => {
    const { make, repo } = setup();
    const a = make();
    await a.createProject("P");
    const id = a.getState().bundle!.project.id;
    a.renameProject("X");
    await a.flushAutosave();
    const b = make();
    await b.openProject(id);
    await b.discardRecovery();
    expect(b.getState().recovery).toBeNull();
    expect(await repo.loadAutosave(id)).toBeNull();
  });

  it("cerrar con cambios conserva un autosave", async () => {
    const { make, repo } = setup();
    const a = make();
    await a.createProject("P");
    const id = a.getState().bundle!.project.id;
    a.addScene();
    await a.closeProject();
    expect(a.getState().screen).toBe("inicio");
    expect((await repo.loadAutosave(id))?.bundle.scenes).toHaveLength(2);
  });

  it("duplica y elimina proyectos", async () => {
    const { make } = setup();
    const s = make();
    await s.createProject("Base");
    await s.closeProject();
    const id = s.getState().projects[0]!.id;
    await s.duplicateProject(id);
    const names = s.getState().projects.map((p) => p.name).sort();
    expect(names).toEqual(["Base", "Base (copia)"]);
    await s.deleteProject(id);
    expect(s.getState().projects.map((p) => p.name)).toEqual(["Base (copia)"]);
  });

  it("muestra errores legibles si el proyecto está dañado", async () => {
    const { make, kv } = setup();
    await kv.put("projects", "roto", { project: { name: "Roto", schemaVersion: "1.0.0" }, scenes: [] });
    const s = make();
    await s.openProject("roto");
    expect(s.getState().screen).toBe("inicio");
    expect(s.getState().messages.length > 0).toBe(true);
    expect(s.getState().messages[0]!.level).toBe("error");
    expect(await kv.get("projects", "roto")).toBeDefined();
  });
});
