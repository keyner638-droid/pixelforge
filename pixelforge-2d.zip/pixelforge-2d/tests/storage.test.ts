import { describe, expect, it } from "vitest";
import { createEmptyBundle } from "../src/model";
import { createMemoryKv, createProjectRepository, StorageError } from "../src/storage";

function setup() {
  const kv = createMemoryKv();
  return { kv, repo: createProjectRepository(kv) };
}

describe("repositorio de proyectos", () => {
  it("guarda y reabre un proyecto idéntico", async () => {
    const { repo } = setup();
    const b = createEmptyBundle("Aventura");
    await repo.save(b);
    const r = await repo.load(b.project.id);
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.value).toEqual(b);
  });

  it("lista los proyectos con su resumen", async () => {
    const { repo } = setup();
    const b = createEmptyBundle("Aventura");
    await repo.save(b);
    const list = await repo.list();
    expect(list).toHaveLength(1);
    expect(list[0]).toEqual({
      id: b.project.id,
      name: "Aventura",
      updatedAt: b.project.updatedAt,
      sceneCount: 1,
      damaged: false,
    });
  });

  it("informa si el proyecto no existe", async () => {
    const { repo } = setup();
    const r = await repo.load("nada");
    expect(r.ok).toBe(false);
  });

  it("no guarda un proyecto inválido", async () => {
    const { repo, kv } = setup();
    const b = createEmptyBundle("X");
    b.project.startSceneId = "no-existe";
    let error: unknown;
    try {
      await repo.save(b);
    } catch (e) {
      error = e;
    }
    expect(error instanceof StorageError).toBe(true);
    expect(await kv.entries("projects")).toHaveLength(0);
  });

  it("conserva la versión anterior como backup al volver a guardar", async () => {
    const { repo, kv } = setup();
    const b = createEmptyBundle("V1");
    await repo.save(b);
    const v2 = { ...b, project: { ...b.project, name: "V2" } };
    await repo.save(v2);
    const backup = (await kv.get("backups", b.project.id)) as typeof b;
    expect(backup.project.name).toBe("V1");
    const r = await repo.load(b.project.id);
    expect(r.ok && r.value.project.name).toBe("V2");
  });

  it("muestra un proyecto dañado en la lista sin borrarlo", async () => {
    const { repo, kv } = setup();
    await kv.put("projects", "roto-1", { project: { name: "Roto", schemaVersion: "1.0.0" }, scenes: "mal" });
    const list = await repo.list();
    expect(list).toHaveLength(1);
    expect(list[0]!.damaged).toBe(true);
    expect(list[0]!.name).toBe("Roto");
    const r = await repo.load("roto-1");
    expect(r.ok).toBe(false);
    expect(await kv.get("projects", "roto-1")).toBeDefined();
  });

  it("elimina proyecto, autosave y backup", async () => {
    const { repo, kv } = setup();
    const b = createEmptyBundle("X");
    await repo.save(b);
    await repo.save(b);
    await repo.saveAutosave(b);
    await repo.remove(b.project.id);
    expect(await kv.entries("projects")).toHaveLength(0);
    expect(await kv.entries("autosaves")).toHaveLength(0);
    expect(await kv.entries("backups")).toHaveLength(0);
  });
});

describe("autosave", () => {
  it("se guarda, se recupera y se borra al guardar", async () => {
    const { repo } = setup();
    const b = createEmptyBundle("X");
    await repo.save(b);
    const edited = { ...b, project: { ...b.project, name: "Editado" } };
    await repo.saveAutosave(edited);
    const a = await repo.loadAutosave(b.project.id);
    expect(a?.bundle.project.name).toBe("Editado");
    await repo.save(edited);
    expect(await repo.loadAutosave(b.project.id)).toBeNull();
  });

  it("ignora un autosave dañado", async () => {
    const { repo, kv } = setup();
    await kv.put("autosaves", "p1", { bundle: { project: 1 }, autosavedAt: "x" });
    expect(await repo.loadAutosave("p1")).toBeNull();
  });
});
