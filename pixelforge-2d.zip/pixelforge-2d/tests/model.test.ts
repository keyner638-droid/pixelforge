import { describe, expect, it } from "vitest";
import {
  createEmptyBundle,
  duplicateBundle,
  migrateBundle,
  validateBundle,
  SCHEMA_VERSION,
  type Migration,
} from "../src/model";

const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v)) as T;

describe("proyecto vacío", () => {
  it("es válido y sobrevive a un viaje JSON", () => {
    const b = createEmptyBundle("Mi juego");
    expect(validateBundle(b).ok).toBe(true);
    expect(validateBundle(clone(b)).ok).toBe(true);
    expect(clone(b)).toEqual(b);
  });

  it("usa IDs únicos y una escena inicial", () => {
    const a = createEmptyBundle("A");
    const b = createEmptyBundle("B");
    expect(a.project.id).not.toBe(b.project.id);
    expect(a.scenes).toHaveLength(1);
    expect(a.project.startSceneId).toBe(a.scenes[0]!.id);
    expect(a.project.schemaVersion).toBe(SCHEMA_VERSION);
  });

  it("pone un nombre por defecto si viene vacío", () => {
    expect(createEmptyBundle("   ").project.name).toBe("Proyecto sin nombre");
  });
});

describe("validación", () => {
  it("rechaza datos que no son un proyecto", () => {
    expect(validateBundle(null).ok).toBe(false);
    expect(validateBundle("hola").ok).toBe(false);
  });

  it("indica la ruta del campo con error", () => {
    const b = clone(createEmptyBundle("X"));
    (b.project as unknown as Record<string, unknown>).name = "";
    (b.project.settings as unknown as Record<string, unknown>).targetFps = 25;
    const r = validateBundle(b);
    expect(r.ok).toBe(false);
    if (!r.ok) {
      const paths = r.issues.map((i) => i.path);
      expect(paths).toContain("project.name");
      expect(paths).toContain("project.settings.targetFps");
    }
  });

  it("detecta escena inicial inexistente, escenas repetidas y escenas fuera de la lista", () => {
    const b = clone(createEmptyBundle("X"));
    b.project.startSceneId = "no-existe";
    const r1 = validateBundle(b);
    expect(r1.ok).toBe(false);

    const c = clone(createEmptyBundle("X"));
    c.scenes.push({ ...c.scenes[0]! });
    const r2 = validateBundle(c);
    expect(r2.ok).toBe(false);
    if (!r2.ok) expect(r2.issues.some((i) => i.message.includes("mismo ID"))).toBe(true);

    const d = clone(createEmptyBundle("X"));
    d.scenes.push({ ...d.scenes[0]!, id: "otra" });
    expect(validateBundle(d).ok).toBe(false);
  });

  it("conserva campos desconocidos de versiones futuras", () => {
    const b = clone(createEmptyBundle("X")) as unknown as Record<string, unknown>;
    b.extra = { futuro: true };
    const r = validateBundle(b);
    expect(r.ok).toBe(true);
    if (r.ok) expect((r.value as unknown as Record<string, unknown>).extra).toEqual({ futuro: true });
  });
});

describe("duplicar", () => {
  it("genera IDs nuevos y mantiene la escena inicial coherente", () => {
    const a = createEmptyBundle("Original");
    const b = duplicateBundle(a, "Copia");
    expect(b.project.id).not.toBe(a.project.id);
    expect(b.scenes[0]!.id).not.toBe(a.scenes[0]!.id);
    expect(b.project.startSceneId).toBe(b.scenes[0]!.id);
    expect(validateBundle(b).ok).toBe(true);
    expect(a.scenes[0]!.name).toBe(b.scenes[0]!.name);
  });
});

describe("migraciones", () => {
  it("acepta la versión actual", () => {
    expect(migrateBundle(createEmptyBundle("X")).ok).toBe(true);
  });

  it("rechaza una versión mayor más nueva sin modificar los datos", () => {
    const b = clone(createEmptyBundle("X"));
    b.project.schemaVersion = "2.0.0";
    const r = migrateBundle(b);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.issues[0]!.message).toContain("más nueva");
    expect(b.project.schemaVersion).toBe("2.0.0");
  });

  it("acepta una versión menor más nueva dentro de la misma mayor", () => {
    const b = clone(createEmptyBundle("X"));
    b.project.schemaVersion = "1.4.0";
    expect(migrateBundle(b).ok).toBe(true);
  });

  it("rechaza una versión anterior sin migración registrada", () => {
    const b = clone(createEmptyBundle("X"));
    b.project.schemaVersion = "0.5.0";
    expect(migrateBundle(b).ok).toBe(false);
  });

  it("aplica una migración registrada sin tocar el original", () => {
    const old = clone(createEmptyBundle("X"));
    old.project.schemaVersion = "0.9.0";
    const migrations: Migration[] = [
      {
        from: "0.9.0",
        to: SCHEMA_VERSION,
        run: (raw) => ({ ...raw, migrado: true }),
      },
    ];
    const r = migrateBundle(old, migrations);
    expect(r.ok).toBe(true);
    if (r.ok) {
      const v = r.value as { migrado: boolean; project: { schemaVersion: string } };
      expect(v.migrado).toBe(true);
      expect(v.project.schemaVersion).toBe(SCHEMA_VERSION);
    }
    expect(old.project.schemaVersion).toBe("0.9.0");
  });

  it("detecta ciclos de migración", () => {
    const old = clone(createEmptyBundle("X"));
    old.project.schemaVersion = "0.1.0";
    const loop: Migration[] = [
      { from: "0.1.0", to: "0.2.0", run: (r) => r },
      { from: "0.2.0", to: "0.1.0", run: (r) => r },
    ];
    expect(migrateBundle(old, loop).ok).toBe(false);
  });
});
